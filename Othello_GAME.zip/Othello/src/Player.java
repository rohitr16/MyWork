import java.awt.Color;

import javax.swing.Icon;


public class Player {
	
	String name;
	Color color;
	Icon icon;
	

}
